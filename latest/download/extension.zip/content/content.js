// 创建搜同款按钮
function createSearchButton() {
  const button = document.createElement('button');
  button.className = 'similar-search-btn';
  button.textContent = '搜同款';
  button.style.display = 'none';
  document.body.appendChild(button);
  return button;
}

// 初始化按钮和事件监听
const searchButton = createSearchButton();
let currentImage = null;

// 处理图片悬停事件
document.addEventListener('mouseover', (e) => {
  if (e.target.tagName === 'IMG' && e.target.width > 100 && e.target.height > 100) {
    currentImage = e.target;
    const rect = e.target.getBoundingClientRect();
    searchButton.style.left = `${rect.right - 60}px`;
    searchButton.style.top = `${rect.top + 10}px`;
    searchButton.style.display = 'block';
  }
});

// 处理鼠标离开事件
document.addEventListener('mouseout', (e) => {
  if (!e.relatedTarget || !e.relatedTarget.classList.contains('similar-search-btn')) {
    searchButton.style.display = 'none';
    currentImage = null;
  }
});

// 处理按钮点击事件
searchButton.addEventListener('click', async () => {
  if (currentImage) {
    // 打开搜索页面
    const searchUrl = chrome.runtime.getURL('search/search.html');
    const searchTab = await chrome.runtime.sendMessage({
      type: 'OPEN_SEARCH_TAB',
      imageUrl: currentImage.src
    });
  }
}); 