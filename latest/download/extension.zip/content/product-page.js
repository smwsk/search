// 监听页面变化
const observer = new MutationObserver(() => {
  // 检查是否已添加下载按钮
  if (document.querySelector('.download-images-btn')) return;
  
  // 查找轮播图容器
  const galleryContainer = document.querySelector('div[class^="_1CQ4cRYC"]');
  if (!galleryContainer) return;
  
  // 创建按钮容器
  const buttonContainer = document.createElement('div');
  buttonContainer.style.cssText = `
    position: absolute;
    top: 20px;
    left: 0;
    right: 0;
    display: flex;
    justify-content: center;
    z-index: 1000;
  `;
  
  // 创建下载按钮
  const downloadBtn = document.createElement('button');
  downloadBtn.className = 'download-images-btn';
  downloadBtn.textContent = '下载所有图片';
  
  // 添加点击事件
  downloadBtn.addEventListener('click', async () => {
    try {
      downloadBtn.classList.add('loading');
      downloadBtn.textContent = '下载中...';
      
      // 获取所有图片URL
      const images = Array.from(document.querySelectorAll('div[class^="_22_BWn2A"] img'))
        .map(img => img.src)
        .filter(Boolean)
        .map(url => url.split('?')[0]) // 移除所有图片参数，获取原图
        .filter((url, index, self) => self.indexOf(url) === index); // 去重
      
      if (images.length === 0) {
        throw new Error('未找到商品图片');
      }
      
      console.log('找到图片:', images);
      
      // 创建文件夹名称（使用当前时间戳）
      const folderName = `temu_images_${Date.now()}`;
      
      // 下载所有图片并添加到 ZIP
      for (let index = 0; index < images.length; index++) {
        const url = images[index];
        try {
          console.log(`开始下载图片 ${index + 1}/${images.length}: ${url}`);
          // 通过 background script 下载图片
          const response = await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ 
              type: 'DOWNLOAD_SINGLE_IMAGE',
              url,
              filename: `${folderName}/image_${index + 1}.jpg`
            }, response => {
              if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
                return;
              }
              resolve(response);
            });
          });
          
          if (!response.success) {
            throw new Error(response.error || '下载失败');
          }
          
          console.log(`图片 ${index + 1} ���载完成`);
        } catch (error) {
          console.error(`下载图片 ${index + 1} 失败:`, error);
          // 继续下载其他图片，而不是直接失败
        }
      }
      
      console.log('所有图片下载完成');
      
      downloadBtn.textContent = '下载成功';
      setTimeout(() => {
        downloadBtn.textContent = '下载所有图片';
      }, 2000);
      
    } catch (error) {
      console.error('下载失败:', error);
      downloadBtn.textContent = '下载失败';
      setTimeout(() => {
        downloadBtn.textContent = '下载所有图片';
      }, 2000);
    } finally {
      downloadBtn.classList.remove('loading');
    }
  });
  
  // 将按钮添加到页面
  buttonContainer.appendChild(downloadBtn);
  galleryContainer.insertBefore(buttonContainer, galleryContainer.firstChild);
});

// 开始监听
observer.observe(document.body, {
  childList: true,
  subtree: true
}); 