// 监听清理数据的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'CLEAR_PAGE_DATA') {
    try {
      // 清理 localStorage
      localStorage.clear();
      
      // 清理 sessionStorage
      sessionStorage.clear();
      
      // 清理 indexedDB
      indexedDB.databases().then(dbs => {
        dbs.forEach(db => {
          indexedDB.deleteDatabase(db.name);
        });
      });
      
      // 清理 cookies
      document.cookie.split(';').forEach(cookie => {
        const name = cookie.split('=')[0].trim();
        document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`;
      });
      
      sendResponse({ success: true });
    } catch (error) {
      console.error('清理页面数据失败:', error);
      sendResponse({ success: false, error: error.message });
    }
  }
}); 