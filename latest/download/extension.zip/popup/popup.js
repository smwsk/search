// 当前选中的平台
let currentPlatform = 'shein';

// 初始化标签页切换
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    
    const platform = btn.dataset.platform;
    showPlatformResults(platform);
  });
});

// 显示指定平台的结果
function showPlatformResults(platform) {
  document.querySelectorAll('.platform-results').forEach(div => {
    div.classList.remove('active');
  });
  document.getElementById(`${platform}-results`).classList.add('active');
  currentPlatform = platform;
}

// 创建商品卡片
function createProductCard(product) {
  return `
    <a href="${product.url}" target="_blank" class="product-card">
      <img class="product-image" src="${product.image}" alt="${product.title}">
      <div class="product-title">${product.title}</div>
      <div class="product-info">
        <span class="price">${product.price}</span>
        <span class="sales">月销 ${product.sales}</span>
      </div>
    </a>
  `;
}

// 添加加载状态和错误处理
function showLoading() {
  document.querySelectorAll('.platform-results').forEach(div => {
    div.innerHTML = '<div class="loading">正在搜索中...</div>';
  });
}

function showError(message) {
  document.querySelectorAll('.platform-results').forEach(div => {
    div.innerHTML = `<div class="error">${message}</div>`;
  });
}

// 监听消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'LOADING_STATUS':
      if (message.loading) {
        showLoading();
      }
      break;
      
    case 'SEARCH_ERROR':
      showError(message.error);
      break;
      
    case 'SEARCH_RESULTS':
      const { shein, temu, amazon } = message.results;
      
      // 更新各平台结果
      document.getElementById('shein-results').innerHTML = 
        shein.length ? shein.map(createProductCard).join('') : '<div class="no-results">未找到相关商品</div>';
      document.getElementById('temu-results').innerHTML = 
        temu.length ? temu.map(createProductCard).join('') : '<div class="no-results">未找到相关商品</div>';
      document.getElementById('amazon-results').innerHTML = 
        amazon.length ? amazon.map(createProductCard).join('') : '<div class="no-results">未找到相关商品</div>';
        
      showPlatformResults(currentPlatform);
      break;
  }
}); 