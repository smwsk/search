// 添加隐私声明
const PRIVACY_POLICY = {
  dataCollection: [
    '搜索关键词',
    '搜索图片',
    '基本使用统计'
  ],
  dataUsage: [
    '改进搜索结果',
    '优化用户体验'
  ],
  dataProtection: [
    '本地存储加密',
    '定期清理缓存',
    '不与第三方共享'
  ]
}; 