export const UPDATE_CONFIG = {
  // 更新检查配置
  check: {
    // 更新服务器地址
    baseUrl: 'https://raw.githubusercontent.com/smwsk/search/main',
    // 版本检查接口
    versionUrl: '/version.json',
    // 更新包下载地址
    downloadUrl: '/releases/latest/download/extension.zip',
    // 更新日志地址
    changelogUrl: '/changelog.json',
    // 检查间隔(毫秒)
    interval: 24 * 60 * 60 * 1000, // 24小时
  },
  
  // 通知配置
  notification: {
    // 通知ID
    id: 'update-available',
    // 通知图标
    icon: '/assets/icons/icon128.png',
    // 通知标题
    title: '发现新版本',
    // 通知按钮
    buttons: [
      { title: '立即更新' },
      { title: '稍后提醒' }
    ]
  }
}; 