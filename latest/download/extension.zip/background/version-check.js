import { UPDATE_CONFIG } from './config/update-config.js';

class VersionCheck {
  static CHECK_INTERVAL = UPDATE_CONFIG.check.interval;
  
  static async checkForUpdates() {
    try {
      // 检查上次检查时间
      const { lastCheck } = await chrome.storage.local.get('lastCheck');
      const now = Date.now();
      
      if (lastCheck && (now - lastCheck < this.CHECK_INTERVAL)) {
        return; // 24小时内已检查过
      }
      
      // 更新检查时间
      await chrome.storage.local.set({ lastCheck: now });
      
      // 获取当前版本
      const manifest = chrome.runtime.getManifest();
      const currentVersion = manifest.version;
      
      // 检查最新版本
      const response = await fetch(`${UPDATE_CONFIG.check.baseUrl}${UPDATE_CONFIG.check.versionUrl}`);
      const { version, updateUrl, changelog } = await response.json();
      
      // 比较版本
      if (this.compareVersions(version, currentVersion) > 0) {
        // 发送更新通知
        this.notifyUpdate(version, updateUrl, changelog);
      }
    } catch (error) {
      console.error('检查更新失败:', error);
    }
  }
  
  static compareVersions(v1, v2) {
    const parts1 = v1.split('.').map(Number);
    const parts2 = v2.split('.').map(Number);
    
    for (let i = 0; i < 3; i++) {
      if (parts1[i] > parts2[i]) return 1;
      if (parts1[i] < parts2[i]) return -1;
    }
    return 0;
  }
  
  static async notifyUpdate(newVersion, updateUrl, changelog) {
    // 创建通知
    chrome.notifications.create('update-available', {
      type: 'basic',
      iconUrl: UPDATE_CONFIG.notification.icon,
      title: UPDATE_CONFIG.notification.title,
      message: `新版本 ${newVersion} 已发布，点击查看更新内容`,
      buttons: UPDATE_CONFIG.notification.buttons,
      requireInteraction: true
    });
    
    // 存储更新信息
    await chrome.storage.local.set({
      pendingUpdate: {
        version: newVersion,
        url: updateUrl,
        changelog
      }
    });
  }
  
  static async handleUpdateClick(buttonIndex) {
    const { pendingUpdate } = await chrome.storage.local.get('pendingUpdate');
    if (!pendingUpdate) return;
    
    if (buttonIndex === 0) { // 立即更新
      chrome.tabs.create({ url: pendingUpdate.url });
    } else { // 稍后提醒
      // 24小时后再次提醒
      setTimeout(() => this.checkForUpdates(), this.CHECK_INTERVAL);
    }
  }
}

// 监听通知点击
chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
  if (notificationId === 'update-available') {
    VersionCheck.handleUpdateClick(buttonIndex);
  }
});

// 定期检查更新
chrome.alarms.create('version-check', {
  periodInMinutes: 1440 // 24小时
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'version-check') {
    VersionCheck.checkForUpdates();
  }
});

// 首次安装或更新时检查
chrome.runtime.onInstalled.addListener(() => {
  VersionCheck.checkForUpdates();
}); 