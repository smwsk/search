// 随机延迟函数
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// User-Agent 池
const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
  // 添加更多 UA
];

// 代理池配置
const PROXY_POOL = [
  // 这里填入你的代理服务器列表
  // 'http://proxy1.example.com:8080',
  // 'http://proxy2.example.com:8080'
];

class AntiCrawler {
  static getRandomUserAgent() {
    return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
  }

  static getRandomProxy() {
    if (PROXY_POOL.length === 0) return null;
    return PROXY_POOL[Math.floor(Math.random() * PROXY_POOL.length)];
  }

  // Cookie 管理
  static async manageCookies(platform) {
    const cookies = await chrome.cookies.getAll({ domain: `.${platform}.com` });
    if (!cookies.length) {
      console.log(`需要登录${platform}平台`);
      return false;
    }
    return true;
  }

  // IP 轮换
  static async rotateIP() {
    const proxy = this.getRandomProxy();
    if (!proxy) return null;
    
    try {
      await fetch(proxy + '/rotate');
      return proxy;
    } catch (error) {
      console.error('IP轮换失败:', error);
      return null;
    }
  }

  // 请求频率限制
  static async rateLimit(platform) {
    const key = `lastRequest_${platform}`;
    const minInterval = 2000; // 最小请求间隔(ms)

    const lastRequest = await chrome.storage.local.get(key);
    const now = Date.now();

    if (lastRequest[key]) {
      const timeDiff = now - lastRequest[key];
      if (timeDiff < minInterval) {
        await sleep(minInterval - timeDiff);
      }
    }

    await chrome.storage.local.set({ [key]: now });
  }

  // 生成请求指纹
  static generateFingerprint() {
    return {
      screen: {
        width: 1920,
        height: 1080,
        colorDepth: 24,
      },
      timezone: 'Asia/Shanghai',
      language: 'zh-CN',
      platform: 'Win32',
      webdriver: false,
    };
  }
}

export { AntiCrawler }; 