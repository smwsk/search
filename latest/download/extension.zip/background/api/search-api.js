import { API_CONFIG } from './config/api-config.js';
import { SheinParser } from './parsers/shein-parser.js';
import { HtmlParser } from './parsers/html-parser.js';
import { AntiCrawler } from './anti-crawler.js';
import { TemuParser } from './parsers/temu-parser.js';

export class SearchService {
  static async searchByKeyword(platform, keyword, options = {}) {
    const config = API_CONFIG[platform]?.keyword;
    if (!config) throw new Error(`不支持的平台: ${platform}`);

    try {
      let url = config.url;
      let requestOptions = {
        method: config.method,
        headers: config.headers
      };

      if (config.method === 'GET') {
        const params = new URLSearchParams();
        
        if (platform === 'amazon') {
          params.append('k', keyword);
        } else {
          params.append('keyword', keyword);
          if (platform === 'shein' || platform === 'temu') {
            params.append('size', options.size || config.params.size);
          }
        }

        if (config.params) {
          Object.entries(config.params).forEach(([key, value]) => {
            if (key !== 'size') {
              params.append(key, value);
            }
          });
        }
        
        url = `${url}?${params.toString()}`;
      } else {
        requestOptions.body = JSON.stringify({ 
          keyword,
          ...config.params,
          size: options.size || config.params.size
        });
      }

      const response = await fetch(url, requestOptions);
      return await this.handleResponse(platform, response);
    } catch (error) {
      console.error(`${platform}关键词搜索错误:`, error);
      return [];
    }
  }

  static async searchByImage(platform, imageUrl, options = {}) {
    const config = API_CONFIG[platform]?.image;
    if (!config) throw new Error(`不支持的平台图片搜索: ${platform}`);

    try {
      let url = config.url;
      let requestOptions = {
        method: config.method,
        headers: config.headers
      };

      if (platform === 'shein') {
        const params = new URLSearchParams(config.params);
        url = `${url}?${params.toString()}`;

        const formData = new URLSearchParams();
        formData.append('sort', '');
        formData.append('filter_goods_id', '');
        formData.append('img_url', imageUrl);

        requestOptions.body = formData.toString();
        
        const authHeaders = await this.getSheinAuthHeaders();
        requestOptions.headers = {
          ...requestOptions.headers,
          ...authHeaders
        };
      } else if (platform === 'temu') {
        const formData = new FormData();
        formData.append('image_url', imageUrl);
        formData.append('size', options.size || config.params.size);
        requestOptions.body = formData;
      } else if (platform === 'amazon') {
        const formData = new FormData();
        formData.append('image', await this.urlToBlob(imageUrl));
        requestOptions.body = formData;
      }

      const response = await fetch(url, requestOptions);
      return await this.handleResponse(platform, response);
    } catch (error) {
      console.error(`${platform}图片搜索错误:`, error);
      return [];
    }
  }

  static async urlToBlob(url) {
    const response = await fetch(url);
    return await response.blob();
  }

  static async handleResponse(platform, response) {
    if (!response.ok) {
      throw new Error(`请求失败: ${response.status}`);
    }

    try {
      if (platform === 'amazon') {
        const html = await response.text();
        return HtmlParser.parse(platform, html);
      } else {
        const data = await response.json();
        
        if (data.code !== 0) {
          throw new Error(data.message || '未知错误');
        }

        switch (platform) {
          case 'shein':
            return SheinParser.parse(data);
          case 'temu':
            return TemuParser.parse(data);
          default:
            return [];
        }
      }
    } catch (error) {
      console.error(`${platform}数据解析错误:`, error);
      return [];
    }
  }

  static async getSheinAuthHeaders() {
    try {
      return {
        'Cookie': await this.getSheinCookie(),
        'armorToken': await this.getArmorToken(),
        'x-csrf-token': await this.getCsrfToken(),
        'x-gw-auth': await this.getGwAuth(),
        'SmDeviceId': await this.getDeviceId()
      };
    } catch (error) {
      console.error('获取SHEIN认证头失败:', error);
      return {};
    }
  }

  static async getSheinCookie() {
    try {
      const hasPermission = await chrome.permissions.contains({
        permissions: ['cookies'],
        origins: ["https://*.shein.com/*"]
      });
      
      if (!hasPermission) {
        const granted = await requestCookiePermission();
        if (!granted) {
          throw new Error('需要 Cookie 权限来进行图片搜索');
        }
      }
      
      const cookies = await chrome.cookies.getAll({
        domain: '.shein.com'
      });
      return cookies.map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
    } catch (error) {
      console.error('获取Cookie失败:', error);
      return '';
    }
  }

  static async getArmorToken() {
    return 'T0_3.1.0_eg46TTz8UE4EyDcBKc_PVSysyyp22ZdFuWzs5e7Iw4T9Kv5T3FjNvXFO32BmqiBC4Y-QMGdn_R_amobNf2qL1a8upLkxy5VI_28YhFs-4BkmiIIiu4hSHQXS-GkqcBxVLnK3z2cDY-y-dsRpuBSbw-jb8ifZoAvGl14t4KGBJSTa0Koe4O_WEMVOjzlViqXl_1734537727743';
  }

  static async getCsrfToken() {
    return 'YdE254It-xHrbzNnDHii3_vmS0R3MrC5935k';
  }

  static async getGwAuth() {
    return 'a=xjqHR52UWJdjKJ0x6QrCsus66rNXR9@2.0.13&b=1734537767630&d=06942fbc37be6a98b8dee877d03ae8f6&e=Rr3ezOTI4YWNkNTFmN2NlOTVlNzVlMzkxYzkzZTY2YzE5YWRmZjBjNzlkYzgyMDI0ZDYzYzdlMTFiZWNiZTBjNjYwNA%3D%3D';
  }

  static async getDeviceId() {
    return 'JMrwNw1k/GM3Z6m+Utp5QTXbNoR7DWNYl2RXhT8lCkYfbuTwrb3HVXsBkBedk5yaCyYoia3MwUOGkd/b/u0W3WycZA+necgdCW1tldyDzmQI99+chXEihb2y23ifdfpYp5HxsF710xU/V4b7llpcwCHPPxycwCneu8bpbMPuOTJc3aMEBGDbBdvn7K5wmPcS1rQHL47zEBiNVCcw5ywKBbbGuPTfrXpB7yyk8NDoPTw9kstEOBhElkzhkBqD1cTe5685hmEETs=1487582755342';
  }
} 