export class HtmlParser {
  static SELECTORS = {
    shein: {
      itemContainer: '.S-product-item',
      title: '.S-product-item__name',
      image: '.S-product-item__img-container img',
      price: '.S-product-item__price',
      sales: '.S-product-item__sold-text',
      link: '.S-product-item__link'
    },
    temu: {
      itemContainer: '.product-item',
      title: '.product-title',
      image: '.product-img img',
      price: '.product-price',
      sales: '.product-sales',
      link: '.product-link'
    },
    amazon: {
      itemContainer: 'div[data-asin]',
      title: 'h2 span',
      image: 'img.s-image',
      price: 'span.a-price span.a-offscreen',
      sales: '.a-size-small.a-color-secondary',
      link: 'a.a-link-normal[href*="/dp/"]'
    }
  };

  static parse(platform, html) {
    try {
      html = this.decodeHtmlEntities(html);
      const products = [];
      const selectors = this.SELECTORS[platform];
      
      if (platform === 'amazon') {
        const productDivs = html.match(/<div[^>]+data-asin="[^"]*"[^>]*>[\s\S]*?<\/div>\s*<\/div>/g) || [];
        
        console.log(`找到 ${productDivs.length} 个商品块`);

        for (let i = 0; i < productDivs.length; i++) {
          const div = productDivs[i];
          try {
            // 解码HTML实体
            const decodedDiv = this.decodeHtmlEntities(div);
            // 尝试解析data-asinAdAttributesProps
            const propsMatch = decodedDiv.match(/data-asinAdAttributesProps="([^"]*)"/);
            if (propsMatch) {
              try {
                if (!this.isJsonString(propsMatch[1])) {
                  throw new Error('Invalid JSON string');
                }
                const props = JSON.parse(propsMatch[1]);
                const product = {
                  title: props.productComponents?.title || '',
                  image: props.imageUrl || '',
                  price: this.extractPrice(decodedDiv),
                  sales: {
                    day: 0,
                    week: 0,
                    month: 0,
                    total: props.productComponents?.customerReviews ? 
                      JSON.parse(props.productComponents.customerReviews).count.replace(/,/g, '') : 0
                  },
                  url: props.productUrl || '',
                  onSaleTime: '未知',
                  debug: {
                    platform: 'amazon',
                    asin: props.asin
                  }
                };
                
                if (this.isValidProduct(product)) {
                  products.push(product);
                }
                continue;
              } catch (e) {
                console.warn('解析JSON属性失败:', e);
              }
            }

            // 如果无法从属性中获取，则使用常规解析方式
            const asinMatch = decodedDiv.match(/data-asin="([^"]*)"/);
            if (!asinMatch || !asinMatch[1]) continue;

            const titleMatch = decodedDiv.match(/alt="([^"]+?)(?:\s*,\s*[^"]+)?"/);
            const title = titleMatch ? titleMatch[1].trim() : '';

            const imageMatch = decodedDiv.match(/<img[^>]*class="[^"]*s-image[^"]*"[^>]*src="([^"]+)"[^>]*>/);
            const image = imageMatch ? imageMatch[1] : '';

            const price = this.extractPrice(decodedDiv);

            const hrefMatch = decodedDiv.match(/href="([^"]*\/dp\/[^\/]+\/[^"]*?)"/);
            const url = hrefMatch ? 
              (hrefMatch[1].startsWith('http') ? hrefMatch[1] : `https://www.amazon.com${hrefMatch[1]}`) : '';

            // console.log(title, image, url);
            if (title && image && url) {
              const product = {
                title,
                image,
                price,
                sales: {
                  day: 0,
                  week: 0,
                  month: 0,
                  total: 0
                },
                url,
                onSaleTime: '未知',
                debug: {
                  platform: 'amazon',
                  asin: asinMatch[1]
                }
              };

              products.push(product);
            }
          } catch (error) {
            console.warn(`解析第 ${i + 1} 个商品时出错:`, error);
          }
        }

        console.log(`成功解析 ${products.length} 个商品`);
      } else {
        const itemRegex = this.createRegexForSelector(selectors.itemContainer);
        const items = html.match(new RegExp(itemRegex, 'g')) || [];

        for (const itemHtml of items) {
          try {
            const product = {
              title: this.extractByRegex(itemHtml, selectors.title),
              image: this.extractSrcByRegex(itemHtml, selectors.image),
              price: this.extractByRegex(itemHtml, selectors.price),
              sales: '', 
              url: this.extractHrefByRegex(itemHtml, selectors.link),
              onSaleTime: '未知',
              debug: {
                platform: platform
              }
            };

            if (product.url && !product.url.startsWith('http')) {
              product.url = `https://www.amazon.com${product.url}`;
            }

            if (this.isValidProduct(product)) {
              products.push(product);
            }
          } catch (error) {
            console.warn('商品解析错误:', error);
          }
        }
      }

      return products;
    } catch (error) {
      console.error('HTML解析错误:', error);
      return [];
    }
  }

  static createRegexForSelector(selector) {
    // 简单转换CSS选择器为正则表达式
    return selector
      .replace('.', '\\s*class=["\'][^"\']*?')
      .replace('#', '\\s*id=["\']')
      .replace('[', '\\[')
      .replace(']', '\\]');
  }

  static extractByRegex(html, selector) {
    try {
      let regex;
      if (selector === 'span[data-label-id]') {
        // 特殊处理标
        regex = new RegExp(`<span[^>]*data-label-id="[^"]*"[^>]*>([^<]+)</span>`, 'i');
      } else if (selector.includes('span.a-price')) {
        // 特殊处理价格
        regex = new RegExp(`<span[^>]*class="[^"]*a-price[^"]*"[^>]*>.*?<span[^>]*class="[^"]*a-offscreen[^"]*"[^>]*>([^<]+)</span>`, 'i');
      } else {
        // 默认文本提取
        regex = new RegExp(`<[^>]*${selector.replace(/\./g, ' [^>]*class="[^"]*')}[^>]*>([^<]+)</`, 'i');
      }
      
      const match = html.match(regex);
      if (!match) {
        return '';
      }
      return match[1].trim();
    } catch (error) {
      console.error('提取文本错误:', error);
      return '';
    }
  }

  static extractSrcByRegex(html, selector) {
    try {
      // 更新图片提取逻辑，只获取 src 属性，忽略 srcset
      const regex = new RegExp(`<img[^>]*class="[^"]*s-image[^"]*"[^>]*src="([^"]+)"`, 'i');
      const match = html.match(regex);
      if (!match) {
        return '';
      }
      return match[1];
    } catch (error) {
      console.error('提取图片错误:', error);
      return '';
    }
  }

  static extractHrefByRegex(html, selector) {
    try {
      const regex = new RegExp(`${this.createRegexForSelector(selector)}[^>]*?href=["']([^"']+)["']`);
      const match = html.match(regex);
      return match ? match[1] : '';
    } catch (error) {
      return '';
    }
  }

  static isValidProduct(product) {
    return product.title && product.image && product.url;
  }

  // 添加HTML解码方法
  static decodeHtmlEntities(text) {
    const entities = {
      '&quot;': '"',
      '&amp;': '&',
      '&lt;': '<',
      '&gt;': '>',
      '&nbsp;': ' '
    };
    return text.replace(/&[^;]+;/g, (entity) => entities[entity] || entity);
  }

  // 添加价格提取方法
  static extractPrice(html) {
    const pricePatterns = [
      /(?:"price":|class="a-price"[^>]*>)[^$]*\$?\s*([0-9,]+\.?[0-9]*)/,
      /"price":"?\$?([0-9,]+\.?[0-9]*)"/,
      /\$([0-9,]+\.?[0-9]*)/,
      /<span[^>]*class="a-offscreen"[^>]*>([^<]+)<\/span>/,
      /<span[^>]*class="a-price-whole"[^>]*>([^<]+)<\/span>/
    ];
    for (const pattern of pricePatterns) {
      const match = html.match(pattern);
      console.log(pattern);
      if (match) {
        return `$${match[1].replace(/,/g, '')}`;
      }
    }
    return '';
  }
} 