export class SheinParser {
  static parse(data) {
    try {
      if (!data.data || !Array.isArray(data.data.list)) {
        return [];
      }

      return data.data.list.map(item => {
        let onSaleTimeStr = '未知';
        if (item.onSaleTime) {
          try {
            const date = new Date(item.onSaleTime);
            onSaleTimeStr = date.toLocaleString('zh-CN', {
              year: 'numeric',
              month: '2-digit',
              day: '2-digit',
              hour: '2-digit',
              minute: '2-digit'
            }).replace(/\//g, '-');
          } catch (e) {
            console.error('日期解析错误:', e);
          }
        }

        return {
          title: item.goodsName || '',
          image: item.thumbnail ? `https:${item.thumbnail}` : '',
          price: `¥${item.minPrice || 0}`,
          sales: {
            day: item.daySold || 0,
            week: item.weekSold || 0,
            month: item.monthSold || 0,
            total: item.totalSold || 0
          },
          onSaleTime: onSaleTimeStr,
          url: `https://us.shein.com/goods-detail-p-${item.goodsId}.html`,
          debug: {
            id: item.id,
            goodsId: item.goodsId,
            goodsScore: item.goodsScore
          }
        };
      });
    } catch (error) {
      console.error('SHEIN结果解析错误:', error);
      return [];
    }
  }
} 