export class TemuParser {
  static parse(data) {
    try {
      console.log('Temu解析数据:', data);
      
      if (!data.data || !Array.isArray(data.data.list)) {
        console.log('Temu数据格式不正确:', data);
        return [];
      }

      return data.data.list.map(item => {
        let onSaleTimeStr = '未知';
        if (item.mallOpenTime) {
          try {
            const date = new Date(item.mallOpenTime);
            onSaleTimeStr = date.toLocaleString('zh-CN', {
              year: 'numeric',
              month: '2-digit',
              day: '2-digit',
              hour: '2-digit',
              minute: '2-digit'
            }).replace(/\//g, '-');
          } catch (e) {
            console.error('日期解析错误:', e);
          }
        }

        return {
          title: item.goodsName || '',
          image: item.thumbnail || '',
          price: `¥${item.minPrice || 0}`,
          sales: {
            day: 0,
            week: item.weekSold || 0,
            month: item.monthSold || 0,
            total: item.sold || 0
          },
          onSaleTime: onSaleTimeStr,
          url: item.goodsId ? `https://www.temu.com/search_result.html?search_key=${item.goodsId}&search_method=user` : '',
          debug: {
            id: item.id,
            goodsId: item.goodsId,
            goodsScore: item.goodsScore
          }
        };
      }).filter(product => this.isValidProduct(product));
    } catch (error) {
      console.error('Temu结果解析错误:', error);
      return [];
    }
  }

  static isValidProduct(product) {
    return product.title && product.image && product.url;
  }
} 