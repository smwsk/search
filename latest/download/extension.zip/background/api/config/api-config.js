export const API_CONFIG = {
  shein: {
    keyword: {
      url: 'https://api.sheinshuju.com/api/v1/goods/search',
      method: 'GET',
      params: {
        page: '1',
        size: '20'
      },
      headers: {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'no-cache',
        'origin': 'https://www.sheinshuju.com',
        'referer': 'https://www.sheinshuju.com/',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36'
      }
    },
    image: {
      url: 'https://m.shein.com/us/bff-api/product/recommend/image_search?_ver=1.1.8&_lang=en',
      method: 'POST',
      headers: {
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'no-cache',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Origin': 'https://m.shein.com',
        'Referer': 'https://m.shein.com/us/presearch?ref=m&ref=m&rep=dir&rep=dir',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'timezone': 'GMT+8',
        'webVersion': '11.9.8'
      }
    }
  },
  temu: {
    keyword: {
      url: 'https://api.temushuju.com/api/v1/goods/search',
      method: 'GET',
      params: {
        page: '1',
        size: '20'
      },
      headers: {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'no-cache',
        'origin': 'https://www.temushuju.com',
        'referer': 'https://www.temushuju.com',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36'
      }
    },
    image: {
      url: 'https://www.temu.com/api/v1/image-search',
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    }
  },
  amazon: {
    keyword: {
      url: 'https://www.amazon.com/s',
      method: 'GET',
      params: {
        ref: 'nb_sb_noss'
      },
      headers: {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'no-cache',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36'
      }
    },
    image: {
      url: 'https://www.amazon.com/api/image-search',
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    }
  }
}; 