import { SearchService } from './api/search-api.js';

// 缓存服务
class CacheService {
  static cache = new Map();
  
  static getKey(platform, imageData, keyword) {
    return `${platform}:${imageData}:${keyword}`;
  }
  
  static get(platform, imageData, keyword) {
    const key = this.getKey(platform, imageData, keyword);
    const cached = this.cache.get(key);
    
    if (cached && Date.now() - cached.timestamp < 3600000) { // 1小时缓存
      return cached.data;
    }
    return null;
  }
  
  static set(platform, imageData, keyword, data) {
    const key = this.getKey(platform, imageData, keyword);
    this.cache.set(key, {
      data,
      timestamp: Date.now()
    });
  }
}

// 权限使用记录
class PermissionUsage {
  static async logCookieAccess(domain, purpose) {
    console.log(`Cookie访问: ${domain}, 用途: ${purpose}`);
  }

  static async logStorageAccess(key, purpose) {
    console.log(`存储访问: ${key}, 用途: ${purpose}`);
  }
}

// 在使用权限时记录
async function getSheinCookie() {
  await PermissionUsage.logCookieAccess('shein.com', '图片搜索认证');
  // ... cookie 获取逻辑
}

// 处理图标点击事件
chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.create({
    url: chrome.runtime.getURL('search/search.html')
  });
});

// 处理消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'SEARCH_PRODUCTS') {
    console.log('收到搜索请求:', request.data);
    
    const { imageUrl, keyword, displayCounts, enabledPlatforms } = request.data;
    
    // 调用搜索处理函数
    handleSearch({ imageUrl, keyword, displayCounts, enabledPlatforms })
      .then(results => {
        console.log('搜索成功:', results);
        sendResponse(results);
      })
      .catch(error => {
        console.error('搜索错误:', error.message, error.stack);
        sendResponse({
          error: error.message,
          shein: [],
          temu: [],
          amazon: []
        });
      });
    
    return true; // 保持消息通道开放
  }
});

// 处理搜索页面的搜索请求
async function handleSearch({ imageUrl, keyword, displayCounts = {}, enabledPlatforms = [] }) {
  try {
    console.log('开始处理搜索:', { imageUrl, keyword, displayCounts, enabledPlatforms });
    
    let searchPromises = [];
    let platformOrder = [];  // 记录平台顺序
    
    // 只搜索启用的平台
    if (enabledPlatforms.includes('shein')) {
      searchPromises.push(
        imageUrl ? 
        SearchService.searchByImage('shein', imageUrl, { size: displayCounts.shein }) :
        SearchService.searchByKeyword('shein', keyword, { size: displayCounts.shein })
      );
      platformOrder.push('shein');
    }
    
    if (enabledPlatforms.includes('temu')) {
      searchPromises.push(
        imageUrl ? 
        SearchService.searchByImage('temu', imageUrl, { size: displayCounts.temu }) :
        SearchService.searchByKeyword('temu', keyword, { size: displayCounts.temu })
      );
      platformOrder.push('temu');
    }
    
    if (enabledPlatforms.includes('amazon')) {
      searchPromises.push(
        imageUrl ? 
        SearchService.searchByImage('amazon', imageUrl) :
        SearchService.searchByKeyword('amazon', keyword)
      );
      platformOrder.push('amazon');
    }

    console.log('发起搜索请求');
    const results = await Promise.allSettled(searchPromises);
    console.log('搜索结果:', results);

    // 构建返回结果
    const response = {
      shein: [],
      temu: [],
      amazon: []
    };

    // 根据平台顺序分配结果
    results.forEach((result, index) => {
      const platform = platformOrder[index];
      response[platform] = result.status === 'fulfilled' ? result.value : [];
    });

    return response;
  } catch (error) {
    console.error('搜索错误:', error.message, error.stack);
    throw error;
  }
}

// 处理网页图片的相似搜索
async function handleSimilarSearch(imgSrc) {
  try {
    // 发送加载状态
    notifyClients('LOADING_STATUS', { loading: true });

    // 并行搜索所有平台
    const results = await handleSearch({ imageData: imgSrc, keyword: '' });
    
    // 发送结果
    notifyClients('SEARCH_RESULTS', { results });
  } catch (error) {
    notifyClients('SEARCH_ERROR', { error: error.message });
  } finally {
    notifyClients('LOADING_STATUS', { loading: false });
  }
}

// 平台搜索函数
async function searchPlatform(platform, { imageUrl, keyword, size }) {
  // 检查缓存
  const cached = CacheService.get(platform, imageUrl || keyword);
  if (cached) return cached;
  
  try {
    let results;
    if (imageUrl) {
      results = await SearchService.searchByImage(platform, imageUrl, { size });
    } else {
      results = await SearchService.searchByKeyword(platform, keyword, { size });
    }
    
    // 存入缓存
    CacheService.set(platform, imageUrl || keyword, results);
    return results;
  } catch (error) {
    console.error(`${platform}搜索错误:`, error);
    return [];
  }
}

// 通知所有客户
function notifyClients(type, data) {
  chrome.runtime.sendMessage({
    type,
    ...data
  });
}

// 清理 TEMU 数据
async function clearTemuData() {
  try {
    console.log('开始清理 TEMU 数据...');
    
    // 记录清理状态
    let cleanStatus = {
      cache: false,
      storage: false,
      cookies: false,
      localStorage: false,
      sessionStorage: false,
      indexedDB: false,
      tabs: false
    };
    
    // 清理缓存数据
    try {
      const cacheKeys = Array.from(CacheService.cache.keys())
        .filter(key => key.startsWith('temu:'));
      
      console.log('找到缓存键:', cacheKeys);
      cacheKeys.forEach(key => {
        CacheService.cache.delete(key);
      });
      cleanStatus.cache = true;
    } catch (error) {
      console.error('清理缓存失败:', error);
    }

    // 清理存储数据
    try {
      const storage = await chrome.storage.local.get(null);
      const temuKeys = Object.keys(storage)
        .filter(key => key.toLowerCase().includes('temu'));
      
      console.log('找到存储键:', temuKeys);
      if (temuKeys.length > 0) {
        await chrome.storage.local.remove(temuKeys);
      }
      
      // 同时清理 sync 存储
      const syncStorage = await chrome.storage.sync.get(null);
      const temuSyncKeys = Object.keys(syncStorage)
        .filter(key => key.toLowerCase().includes('temu'));
      
      if (temuSyncKeys.length > 0) {
        await chrome.storage.sync.remove(temuSyncKeys);
      }
      
      cleanStatus.storage = true;
    } catch (error) {
      console.error('清理存储失败:', error);
    }

    // 检查是否有 cookies 权限
    try {
      const hasPermission = await chrome.permissions.contains({
        permissions: ['cookies'],
        origins: [
          "*://*.temu.com/*",
          "*://temu.com/*"
        ]
      });

      console.log('Cookie权限状态:', hasPermission);

      // 如果有权限，清理 cookies
      if (hasPermission) {
        // 清理所有相关域名的 cookies
        const domains = [
          'www.temu.com',
          '.temu.com',
          'us.temu.com',
          'm.temu.com',
          'temu.com',
          'api.temu.com',
          'img.temu.com',
          'login.temu.com',
          'cart.temu.com'
        ];
        
        for (const domain of domains) {
          console.log(`清理 ${domain} 的 cookies...`);
          try {
            const cookies = await chrome.cookies.getAll({ domain });
            console.log(`找到 ${cookies.length} 个 cookies`);
            
            for (const cookie of cookies) {
              try {
                await chrome.cookies.remove({
                  url: `https://${domain}${cookie.path}`,
                  name: cookie.name,
                  storeId: cookie.storeId
                });
              } catch (error) {
                console.error(`清理 cookie ${cookie.name} 失败:`, error);
              }
            }
          } catch (error) {
            console.error(`获取 ${domain} 的 cookies 失败:`, error);
          }
        }
        cleanStatus.cookies = true;
      }
    } catch (error) {
      console.error('Cookie 清理过程失败:', error);
    }

    // 通知所有 TEMU 页面清理数据
    try {
      const tabs = await chrome.tabs.query({
        url: [
          "*://*.temu.com/*",
          "*://temu.com/*"
        ]
      });
      
      console.log(`找到 ${tabs.length} 个 TEMU 标签页`);

      const tabPromises = tabs.map(async tab => {
        try {
          console.log(`清理标签页 ${tab.id}...`);
          await new Promise((resolve, reject) => {
            chrome.tabs.sendMessage(tab.id, { 
              type: 'CLEAR_PAGE_DATA',
              clearAll: true  // 标记需要清理所有数据
            }, response => {
              if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
              } else {
                resolve(response);
              }
            });
          });
          console.log(`标签页 ${tab.id} 清理成功`);
          
          // 刷新标签页
          await chrome.tabs.reload(tab.id, { bypassCache: true });
        } catch (error) {
          console.error(`清理标签页 ${tab.id} 失败:`, error);
        }
      });

      await Promise.allSettled(tabPromises);
      cleanStatus.tabs = true;
    } catch (error) {
      console.error('标签页清理过程失败:', error);
    }

    const cleanResult = Object.values(cleanStatus).some(status => status);
    console.log('TEMU 数据清理完成，状态:', cleanStatus);
    
    // 只要有一项清理成功就返回 true
    return cleanResult;
    
  } catch (error) {
    console.error('清理 TEMU 数据失败:', error);
    return false;
  }
}

// 监听清理 TEMU 数据的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'CLEAR_TEMU_DATA') {
    console.log('收到清理 TEMU 数据请求');
    clearTemuData()
      .then(success => {
        console.log('清理结果:', success);
        sendResponse({ success });
      })
      .catch(error => {
        console.error('清理过程出错:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }
});

// 只保留必要的权限请求
async function requestCookiePermission() {
  try {
    const granted = await chrome.permissions.request({
      permissions: ['cookies'],
      origins: [
        "https://*.shein.com/*",
        "https://m.shein.com/*"
      ]
    });
    return granted;
  } catch (error) {
    console.error('请求 Cookie 权限失败:', error);
    return false;
  }
}

// 处理图片下载
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'DOWNLOAD_SINGLE_IMAGE') {
    const { url, filename } = request;
    fetch(url)
      .then(response => response.blob())
      .then(blob => {
        // 下载图片
        const reader = new FileReader();
        reader.onloadend = () => {
          chrome.downloads.download({
            url: reader.result,
            filename: filename,
            conflictAction: 'uniquify'
          }, (downloadId) => {
            if (chrome.runtime.lastError) {
              console.error('下载失败:', chrome.runtime.lastError);
              sendResponse({ success: false, error: chrome.runtime.lastError.message });
            } else {
              console.log('下载成功，ID:', downloadId);
              sendResponse({ success: true });
            }
          });
        };
        reader.onerror = () => {
          console.error('读取文件失败:', reader.error);
          sendResponse({ success: false, error: '读取文件失败' });
        };
        reader.readAsDataURL(blob);
      })
      .catch(error => {
        console.error('下载图片失败:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // 保持消息通道开放
  }
  return true;
});