class SearchPage {
  constructor() {
    this.initElements();
    this.loadSettings().then(() => {
      this.bindEvents();
      this.handleUrlParams();
    });
  }

  initElements() {
    this.imageUrlInput = document.getElementById('imageUrlInput');
    this.keywordInput = document.getElementById('keywordInput');
    this.searchButton = document.getElementById('searchButton');
    
    // 添加显示数量输入框的引用
    this.displayCountInputs = {
      shein: document.getElementById('shein-count'),
      temu: document.getElementById('temu-count'),
      amazon: document.getElementById('amazon-count')
    };

    // 添加新元素引用
    this.imageUpload = document.getElementById('imageUpload');
    this.uploadButton = document.getElementById('uploadButton');
    this.previewArea = document.getElementById('previewArea');
    this.previewImage = document.getElementById('previewImage');
    this.removeImage = document.getElementById('removeImage');
    this.uploadPlaceholder = document.getElementById('uploadPlaceholder');
    this.clearTemuBtn = document.getElementById('clearTemuBtn');

    // 添加平台开关用
    this.platformToggles = {
      shein: document.getElementById('shein-toggle'),
      temu: document.getElementById('temu-toggle'),
      amazon: document.getElementById('amazon-toggle')
    };
  }

  // 加载保存的设置
  async loadSettings() {
    try {
      const result = await chrome.storage.local.get(['displayCounts', 'platformStates']);
      const savedCounts = result.displayCounts || {
        shein: 15,
        temu: 15,
        amazon: 15
      };

      // 加载平台状态
      const savedStates = result.platformStates || {
        shein: true,
        temu: true,
        amazon: true
      };

      // 设置输入框的值
      Object.entries(savedCounts).forEach(([platform, count]) => {
        if (this.displayCountInputs[platform]) {
          this.displayCountInputs[platform].value = count;
        }
      });

      // 设置平台开关状态
      Object.entries(savedStates).forEach(([platform, enabled]) => {
        if (this.platformToggles[platform]) {
          this.platformToggles[platform].checked = enabled;
          this.updatePlatformSection(platform, enabled);
        }
      });
    } catch (error) {
      console.error('加载设置失败:', error);
    }
  }

  // 保存设置
  async saveSettings() {
    try {
      const displayCounts = {
        shein: parseInt(this.displayCountInputs.shein?.value) || 15,
        temu: parseInt(this.displayCountInputs.temu?.value) || 15,
        amazon: parseInt(this.displayCountInputs.amazon?.value) || 15
      };

      const platformStates = {
        shein: this.platformToggles.shein?.checked || false,
        temu: this.platformToggles.temu?.checked || false,
        amazon: this.platformToggles.amazon?.checked || false
      };

      await chrome.storage.local.set({ displayCounts, platformStates });
      console.log('设置已保存');
    } catch (error) {
      console.error('保存设置失败:', error);
    }
  }

  bindEvents() {
    // 搜索按钮点击事件
    this.searchButton.addEventListener('click', () => this.handleSearch());

    // 回车键触发搜索
    [this.imageUrlInput, this.keywordInput].forEach(input => {
      input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          this.handleSearch();
        }
      });
    });

    // 监听显示数量的变化
    Object.values(this.displayCountInputs).forEach(input => {
      input.addEventListener('change', () => {
        // 保存设置
        this.saveSettings();
        // 如果已经有搜索结果，立即更新显示
        if (this.lastSearchResults) {
          this.displayResults(this.lastSearchResults);
        }
      });
    });

    // 添加上传相关事件
    this.uploadButton.addEventListener('click', () => {
      this.imageUpload.click();
    });

    this.imageUpload.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (file) {
        try {
          // 显示上传中状态
          this.uploadButton.disabled = true;
          this.uploadButton.textContent = '上传中...';

          const imageUrl = await this.uploadImage(file);
          this.imageUrlInput.value = imageUrl;
          this.showPreview(imageUrl);
        } catch (error) {
          console.error('上传出错:', error);
          alert(error.message || '图片上传失败，请重试');
        } finally {
          // 恢复按钮状态
          this.uploadButton.disabled = false;
          this.uploadButton.textContent = '上传图片';
        }
      }
    });

    // 点击预览区选择
    this.uploadPlaceholder.addEventListener('click', () => {
      this.imageUpload.click();
    });

    this.removeImage.addEventListener('click', () => {
      this.imageUrlInput.value = '';
      this.previewArea.style.display = 'none';
      this.imageUpload.value = '';
      this.uploadPlaceholder.style.display = 'flex';
    });

    // 绑定清理 TEMU 数据按钮事件
    this.clearTemuBtn.addEventListener('click', async () => {
      if (this.clearTemuBtn.classList.contains('loading')) return;
      
      if (!confirm('确定要清除 TEMU 的所有数据吗？\n这将清除缓存、存储数据和 cookies。')) {
        return;
      }
      
      // 在用户点击时请求 cookies 权限
      try {
        const hasPermission = await chrome.permissions.contains({
          permissions: ['cookies'],
          origins: ["https://*.temu.com/*"]
        });
        
        if (!hasPermission) {
          const granted = await chrome.permissions.request({
            permissions: ['cookies'],
            origins: ["https://*.temu.com/*"]
          });
          if (!granted) {
            this.showToast('需要 cookies 权限来完全清理数据');
          }
        }
      } catch (error) {
        console.error('请求权限失败:', error);
      }
      
      try {
        this.clearTemuBtn.classList.add('loading');
        this.clearTemuBtn.textContent = '清除中...';
        
        const response = await new Promise(resolve => {
          chrome.runtime.sendMessage(
            { type: 'CLEAR_TEMU_DATA' },
            resolve
          );
        });
        
        if (response.success) {
          this.showToast('TEMU 数据已清除');
          // 刷新显示的 TEMU 结果
          const temuContainer = document.getElementById('temu-results');
          if (temuContainer) {
            temuContainer.innerHTML = '<div class="no-results">未找到相关商品</div>';
          }
        } else {
          throw new Error(response.error || '清除失败');
        }
      } catch (error) {
        console.error('清除 TEMU 数据失败:', error);
        this.showToast('清除失败: ' + error.message);
      } finally {
        this.clearTemuBtn.classList.remove('loading');
        this.clearTemuBtn.textContent = '清除TEMU数据';
      }
    });

    // 监听平台开关变化
    Object.entries(this.platformToggles).forEach(([platform, toggle]) => {
      toggle.addEventListener('change', () => {
        this.updatePlatformSection(platform, toggle.checked);
        this.saveSettings();
      });
    });

    // 绑定下载按钮事件
    document.addEventListener('click', async (e) => {
      if (e.target.classList.contains('download-btn')) {
        const button = e.target;
        const productId = button.dataset.productId;
        
        try {
          button.classList.add('loading');
          button.textContent = '下载中...';
          
          // 获取商品详情页面
          const response = await fetch(`https://www.temu.com/p/${productId}.html`);
          const html = await response.text();
          
          // 提取轮播图 URL
          const imageUrls = [];
          const imageRegex = /<img[^>]+src="([^"]+)"[^>]*class="[^"]*wxWpAMbp[^"]*"[^>]*>/g;
          let match;
          
          while ((match = imageRegex.exec(html)) !== null) {
            imageUrls.push(match[1]);
          }
          
          if (imageUrls.length === 0) {
            throw new Error('未找到商品图片');
          }
          
          // 发送下载请求
          await new Promise(resolve => {
            chrome.runtime.sendMessage({
              type: 'DOWNLOAD_IMAGES',
              images: imageUrls
            }, resolve);
          });
          
          this.showToast('图片下载成功');
        } catch (error) {
          console.error('下载图片失败:', error);
          this.showToast('下载失败: ' + error.message);
        } finally {
          button.classList.remove('loading');
          button.textContent = '下载图片';
        }
      }
    });
  }

  async handleSearch() {
    const imageUrl = this.imageUrlInput.value.trim();
    const keyword = this.keywordInput.value.trim();
    
    // 检查输入
    if (!imageUrl && !keyword) {
      alert('请输入图片URL或关键词');
      return;
    }

    try {
      this.showLoading();
      
      console.log('开始搜索:', { imageUrl, keyword }); // 添加调试日志
      
      // 获取显示数量设置
      const displayCounts = {
        shein: parseInt(this.displayCountInputs.shein?.value) || 15,
        temu: parseInt(this.displayCountInputs.temu?.value) || 15,
        amazon: parseInt(this.displayCountInputs.amazon?.value) || 15
      };

      console.log('显示数量设置:', displayCounts); // 添加调试日志

      // 获取启用的平台
      const enabledPlatforms = Object.entries(this.platformToggles)
        .filter(([_, toggle]) => toggle.checked)
        .map(([platform]) => platform);

      // 优先使用图片搜索，如果有图片地址就忽略关键词
      const searchParams = imageUrl ? 
        { imageUrl, displayCounts, enabledPlatforms } : 
        { keyword, displayCounts, enabledPlatforms };

      // 发送搜索请求
      const results = await this.searchProducts(searchParams);
      
      console.log('搜索结果:', results); // 添加调试日志
      
      // 保存搜索结果
      this.lastSearchResults = results;
      
      // 显示搜索结果
      this.displayResults(results);
    } catch (error) {
      console.error('搜索失败:', error.message, error.stack);
      alert(`搜索失败: ${error.message || '请重试'}`);
    } finally {
      this.hideLoading();
    }
  }

  async searchProducts(params) {
    return new Promise((resolve, reject) => {
      console.log('发送搜索请求:', params); // 添加调试日志
      
      chrome.runtime.sendMessage({
        type: 'SEARCH_PRODUCTS',
        data: params
      }, response => {
        console.log('收到搜索响应:', response); // 添加调试日志
        
        if (chrome.runtime.lastError) {
          console.error('搜索请求错误:', chrome.runtime.lastError);
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        
        if (!response) {
          reject(new Error('未收到搜索结果'));
          return;
        }
        
        resolve(response);
      });
    });
  }

  showLoading() {
    // 添加加载状态
    document.querySelectorAll('.result-container').forEach(container => {
      container.innerHTML = '<div class="loading">搜索中...</div>';
    });
  }

  hideLoading() {
    // 移除加载状态
    document.querySelectorAll('.loading').forEach(el => el.remove());
  }

  displayResults(results) {
    console.log('显示搜索结果:', results);
    
    // 获取显示数量设置
    const displayCounts = {
      shein: parseInt(this.displayCountInputs.shein?.value) || 15,
      temu: parseInt(this.displayCountInputs.temu?.value) || 15,
      amazon: parseInt(this.displayCountInputs.amazon?.value) || 15
    };

    console.log('当前显示数量设置:', displayCounts);

    // 更新每个平台的结果
    Object.entries(results).forEach(([platform, items]) => {
      // 检查平台是否启用
      if (!this.platformToggles[platform]?.checked) {
        return;
      }
      const container = document.getElementById(`${platform}-results`);
      if (!container) return;

      if (!items || items.length === 0) {
        container.innerHTML = '<div class="no-results">未找到相关商品</div>';
        return;
      }

      // 据平台设置的显示数量截取商品
      const displayCount = Math.min(displayCounts[platform], items.length);
      const displayItems = items.slice(0, displayCount);

      console.log(`${platform} 平台:`, { // 添加调试日志
        总商品数: items.length,
        显示数量: displayCount,
        实际显示: displayItems.length
      });

      // 创建商品网格
      const grid = document.createElement('div');
      grid.className = 'product-grid';

      // 创建并添加商品卡片
      displayItems.forEach((item, index) => {
        const card = document.createElement('div');
        card.className = 'product-card-wrapper';
        card.innerHTML = this.createProductCard(item);
        grid.appendChild(card);
      });

      // 添加网格到容器
      container.appendChild(grid);

      // 显示商品总数和显示数量
      const totalCount = document.createElement('div');
      totalCount.className = 'total-count';
      totalCount.textContent = `共找到 ${items.length} 个商品，显示前 ${displayItems.length} 个`;
      container.appendChild(totalCount);
    });

    // 绑定复制按钮事件
    this.bindCopyButtons();
  }

  createProductCard(product) {
    return `
      <div class="product-card">
        <div class="product-image-container">
          <img src="${product.image}" alt="${product.title}" class="product-image">
        </div>
        <div class="product-info">
          <div class="product-title-container">
            <h3 class="product-title">${product.title}</h3>
            <button class="copy-btn" data-text="${product.title}" title="复制标题">
              <i class="copy-icon">📋</i>
            </button>
          </div>
          <div class="product-price-container">
            <span class="price">${product.price}</span>
            <button class="copy-btn" data-text="${product.price}" title="复制价格">
            </button>
          </div>
          <div class="product-meta">
            ${this.formatSales(product.sales)}
          </div>
          <div class="product-footer">
            ${this.formatOnSaleTime(product.onSaleTime)}
            <a href="${product.url}" target="_blank" class="view-btn">查看</a>
          </div>
        </div>
      </div>
    `;
  }

  // 绑定复制按钮事件
  bindCopyButtons() {
    document.querySelectorAll('.copy-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const text = e.currentTarget.dataset.text;
        try {
          await navigator.clipboard.writeText(text);
          this.showToast('复制成功');
        } catch (err) {
          this.showToast('复制失败');
        }
      });
    });
  }

  // 显示提示信息
  showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('show');
      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
          document.body.removeChild(toast);
        }, 300);
      }, 2000);
    }, 100);
  }

  // 处理URL参数
  handleUrlParams() {
    const urlParams = new URLSearchParams(window.location.search);
    const imageUrl = urlParams.get('image');
    
    if (imageUrl) {
      this.imageUrlInput.value = imageUrl;
      // 自动触发搜索
      setTimeout(() => this.handleSearch(), 500);
    }
  }

  async uploadImage(file) {
    // 检查文件大小
    const MAX_SIZE = 5 * 1024 * 1024; // 5MB
    if (file.size > MAX_SIZE) {
      throw new Error('图片大小不能超过5MB');
    }

    // 检查文件类型
    if (!file.type.startsWith('image/')) {
      throw new Error('请选择正确的图片格式');
    }

    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch('https://api.sheinshuju.com/api/v1/goods/upload-image', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36'
      },
      body: formData
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('上传失败:', errorText);
      throw new Error('图片上传失败，请重试');
    }

    try {
      const result = await response.json();
      if (result && result.data && result.data.url) {
        return result.data.url;
      } else {
        throw new Error('服务器返回数据格式错误');
      }
    } catch (error) {
      console.error('解析应失败:', error);
      throw new Error('图片上传失败，请重试');
    }
  }

  showPreview(imageUrl) {
    this.previewImage.src = imageUrl;
    this.previewArea.style.display = 'block';
    this.uploadPlaceholder.style.display = 'none';
  }

  async uploadToShein(file) {
    try {
      // 将文件转换为 base64
      const reader = new FileReader();
      const imageData = await new Promise((resolve, reject) => {
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      // 通过 background script 上传图片
      const response = await chrome.runtime.sendMessage({
        type: 'UPLOAD_IMAGE_TO_SHEIN',
        data: {
          imageData
        }
      });

      if (response.error) {
        throw new Error(response.error);
      }

      return response.url;
    } catch (error) {
      console.error('上传到 Shein 失败:', error);
      throw error;
    }
  }

  async handleImageUpload(file) {
    try {
      let imageUrl;
      const platform = document.querySelector('input[name="platform"]:checked')?.value;
      
      // 如果是 shein 搜索,使用 shein 的上传接口
      if (platform === 'shein') {
        imageUrl = await this.uploadToShein(file);
      } else {
        imageUrl = await this.uploadImage(file); 
      }

      if (imageUrl) {
        this.imageUrlInput.value = imageUrl;
        this.showPreview(imageUrl);
      }
    } catch(error) {
      console.error('图片上传失败:', error);
      alert('图片上传失败,请重试');
    }
  }

  // 格式化销量显示
  formatSales(sales) {
    // 如果没有销量数据，使用默认值
    const defaultSales = {
      day: '未知',
      week: '未知',
      month: '未知',
      total: '未知'
    };
    
    if (typeof sales === 'object') {
      // 合并默认值和实际数据
      const salesData = { ...defaultSales, ...sales };
      return `
        <span class="sales-item sales-day">日销 ${salesData.day}</span>
        <span class="sales-item sales-week">周销 ${salesData.week}</span>
        <span class="sales-item sales-month">月销 ${salesData.month}</span>
        <span class="sales-item sales-total">总销 ${salesData.total}</span>
      `;
    }
    
    // 如果是简单数字，显示为总销量
    return `
      <span class="sales-item sales-day">日销 未知</span>
      <span class="sales-item sales-week">周销 未知</span>
      <span class="sales-item sales-month">月销 未知</span>
      <span class="sales-item sales-total">总销 ${sales || '未知'}</span>
    `;
  }

  // 格式化上架时间
  formatOnSaleTime(time) {
    if (!time) return '';
    return `<span class="on-sale-time">上架时间: ${time}</span>`;
  }

  // 更新平台区域显示状态
  updatePlatformSection(platform, enabled) {
    const section = document.querySelector(`.platform-section:has(#${platform}-results)`);
    if (section) {
      section.style.display = enabled ? 'block' : 'none';
      // 如果禁用，清空结果
      if (!enabled) {
        const container = document.getElementById(`${platform}-results`);
        if (container) {
          container.innerHTML = '';
        }
      }
    }
  }
}

// 初始化页面
new SearchPage(); 